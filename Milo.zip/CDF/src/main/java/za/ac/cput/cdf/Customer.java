/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.cdf;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author User
 */
public class Customer implements ActionListener {
    private JFrame mainframe ;
    private JPanel panelcenter, panelsouth;
    private  JLabel adminID, adminUsername, adminPassword;
    private JTextField txtadminId , txtadminUsername, txtadminPassword;
    
    private JButton btnadd ;
    
    public Customer(){
    mainframe = new JFrame();
    panelcenter= new JPanel();
    panelsouth= new JPanel();
    
    adminID= new JLabel("Id:");
    adminUsername = new JLabel("name");
    adminPassword = new JLabel("Surname");
    
    txtadminId= new JTextField(25);
    txtadminUsername = new JTextField(5);
    txtadminPassword = new JTextField(5);
    
    btnadd = new JButton ("add");
    
     mainframe.setSize(400,250);
 mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mainframe.setVisible(true);
    
    btnadd.setEnabled(true);
    
    } 
    public void setCustomer(){
    
    panelcenter.setLayout( new GridLayout (3,2));
        panelsouth.setLayout ( new GridLayout (1,1));
        
        panelcenter.add(adminID);
        panelcenter.add(txtadminId);
        
                
        panelcenter.add(adminUsername);
        panelcenter.add(txtadminUsername);
        
        
        panelcenter.add(adminPassword);
        panelcenter.add(txtadminPassword);
        
        panelsouth.add(btnadd);
        
        mainframe.add(panelcenter, BorderLayout.CENTER);
   mainframe.add(panelsouth, BorderLayout.SOUTH);
   
   
   btnadd.addActionListener((ActionListener) this);
    
    }
    
    public static void main(String[] args) {
        new Customer().setCustomer();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
