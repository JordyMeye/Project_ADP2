/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.cdf;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author User
 */
public class House implements ActionListener {
     private JFrame mainframe ;
    private JPanel panelcenter, panelsouth;
    private  JLabel Id, Location, rooms, rent , canRent;
    private JTextField txtId , txtLocation, txtrooms, txtrent, txtcanRent;
    
    private JButton btnadd ;
    
    public House(){
    mainframe = new JFrame();
    panelcenter= new JPanel();
    panelsouth= new JPanel();
    
    Id= new JLabel("Id:");
    Location = new JLabel("Location:");
    rooms= new JLabel("rooms:");
    rent = new JLabel("rent:");
    canRent= new JLabel("canRent:");
    
    
    Id= new JLabel("Id:");
    Location = new JLabel("Location:");
    rooms= new JLabel("rooms:");
    rent = new JLabel("rent:");
    canRent= new JLabel("canRent:");
    
    
    txtId= new JTextField(25);
    txtLocation = new JTextField(25);
    txtrooms= new JTextField(25);
    txtrent = new JTextField();
    txtcanRent= new JTextField(25);
    
    
            
    
    
    
    
    
    btnadd = new JButton ("Send");
    
     mainframe.setSize(400,220);
 mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mainframe.setVisible(true);
    
    btnadd.setEnabled(true);
    
    } 
    public void setHouse(){
    
    panelcenter.setLayout( new GridLayout (6,2));
        panelsouth.setLayout ( new GridLayout (1,1));
        
        panelcenter.add(Id);
        panelcenter.add(txtId);
        
                
        panelcenter.add(Location);
        panelcenter.add(txtLocation);
        
        
        panelcenter.add(rooms);
        panelcenter.add(txtrooms);
        
        panelcenter.add(rent);
        panelcenter.add(txtrent);
        
        panelcenter.add(canRent);
        panelcenter.add(txtcanRent);
        
        panelsouth.add(btnadd);
        
        mainframe.add(panelcenter, BorderLayout.CENTER);
   mainframe.add(panelsouth, BorderLayout.SOUTH);
   
   
   btnadd.addActionListener((ActionListener) this);
    
    }
    
    public static void main(String[] args) {
        new House().setHouse();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}


