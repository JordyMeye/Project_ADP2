/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.cdf;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author User
 */
public class Menu implements ActionListener  {
    
     private JFrame mainframe;
    private JPanel panelcenter;
    private JButton btnadmin, btnagent, btncustomer, btnhouse;
    
    


public Menu(){

mainframe = new JFrame ("");
panelcenter= new JPanel ();



btnadmin = new JButton ("ADD AGENT");
btnagent= new JButton ("ADD AGENT");



btncustomer = new JButton ("ADD CUSTOMER");
btnhouse = new JButton ("ADD HOUSE");



mainframe.setSize(500,250);
 mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mainframe.setVisible(true);
}

public void setMenu(){

    
   
    panelcenter.setLayout( new GridLayout (2,2));
     
 
    
     
     
       
     panelcenter.add(btnadmin);
     panelcenter.add(btnagent);
     
    
     panelcenter.add(btncustomer);
     panelcenter.add(btnhouse);
     
    
     
      mainframe.add(panelcenter, BorderLayout.CENTER);
      


      btnadmin.addActionListener((ActionListener) this);
       btnagent.addActionListener((ActionListener) this);
        btncustomer.addActionListener((ActionListener) this);
         btnhouse.addActionListener((ActionListener) this);
   //AdminGui gui2 = new AdminGui();
      
        
         
}

    public void actionPerformed(ActionEvent e) {
        
           if (e.getSource() == btnadmin){
               
               new AdminGui().setAdminGui();
              
        
        }if (e.getSource() == btnhouse){
         new House().setHouse();
        }
        if (e.getSource() == btnagent){
        new Agent().setAgent();}
        if (e.getSource() == btncustomer){
            
         new Customer().setCustomer();}
        
    }
    public static void main(String[] args) {
        new Menu().setMenu();
    }
}

