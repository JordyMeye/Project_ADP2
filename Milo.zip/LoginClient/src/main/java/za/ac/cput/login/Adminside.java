/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.login;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author User
 */
public class Adminside implements ActionListener {
    
    private JFrame mainframe;
    private JPanel panelcenter, panelnorth;
    private JButton btnadduser, btnaddvenue;
    
    private JButton btnback;


public Adminside(){

mainframe = new JFrame ("Admin");
panelcenter= new JPanel ();
panelnorth= new JPanel();
btnadduser = new JButton ("ADD USER");
btnaddvenue= new JButton ("ADD VENUE");
btnback= new JButton ("back");

mainframe.setSize(500,250);
 mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mainframe.setVisible(true);
}

public void setAdminside(){

     panelcenter.setLayout( new GridLayout (1,2));
     panelnorth.setLayout( new GridLayout (1,1));
     
     
     panelcenter.add(btnadduser);
     panelcenter.add(btnaddvenue);
     
     panelnorth.add(btnback);
     
      mainframe.add(panelcenter, BorderLayout.CENTER);
      mainframe.add(panelnorth, BorderLayout.NORTH);


      btnadduser.addActionListener(this);
   //AdminGui gui2 = new AdminGui();
       btnback.addActionListener(this);
        
          btnaddvenue.addActionListener(this);
}

    @Override
    public void actionPerformed(ActionEvent e) {
        
           if (e.getSource() == btnadduser){
           // new AdminGui().setGui();
         new UserGui().setGui();
        }
        
        if (e.getSource() ==btnaddvenue){
       new AdminGui().setGui();
        }
        if (e.getSource() ==btnback){
        new Gui().setGui();
        }
        
    }
    
    public static void main(String[] args) {
        new Adminside().setAdminside();
    }
}